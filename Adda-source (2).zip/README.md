# Adda - Social, Voice Rooms, Live Streaming (Jetpack Compose)

minSdk 23 (Android 6.0) / targetSdk 36 / compileSdk 36 / Kotlin 2.2 / Compose BOM 2025.06

## Build the APK
1. Install Android Studio (Narwhal or newer) with SDK Platform 36.
2. File > Open > select this folder, wait for Gradle sync.
3. Run on a phone/emulator, or Build > Build APK(s).
   Command line: run `gradle wrapper` once, then `./gradlew assembleDebug`.
   APK: app/build/outputs/apk/debug/app-debug.apk

## What works now (offline demo)
- Login, Home, Voice Rooms (8 seats, take/leave seat, mic mute, speaking ring, room chat, gifts)
- Live list, live viewer (comments, floating hearts), Go Live with real camera preview (CameraX)
- Chat list + 1:1 chat, voice call and video call screens (self-view uses the real camera)
- Foreground service (CallService) keeps the mic alive on seat / in call / while live
- Runtime permissions for mic, camera, notifications

## What is simulated (you must connect it)
Audio/video between different phones needs a media server + accounts:
- data/Data.kt (Repo): fake users, rooms, streams, messages -> replace with Firebase/Supabase/your API.
- rtc/RtcEngine.kt: DemoRtcEngine -> implement `RtcEngine` with Agora, ZEGOCLOUD or LiveKit
  (join/leave/mute/camera). The UI only talks to `Rtc.engine`, so no screen changes are needed.
- Login is local only (name field). Add real auth (phone OTP / Google) in your backend.

## Get the APK without Android Studio (GitHub Actions)
1. Create a GitHub repo, upload this project (keep the .github folder), branch `main`.
2. Open the Actions tab > Build APK > Run workflow (it also runs on every push).
3. When it finishes, download `Adda-debug-apk` from the run's Artifacts, unzip, install app-debug.apk.
