package com.adda.app.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import com.adda.app.data.*
import com.adda.app.rtc.*
import com.adda.app.service.CallService
import com.adda.app.ui.*
import com.adda.app.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.math.sin
import kotlin.random.Random

@Composable
fun HomeScreen(onRoom: (String) -> Unit, onStream: (String) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Hi ${Repo.me.name}", color = TextLo, style = MaterialTheme.typography.bodyMedium)
                    Text("Who is talking tonight?", style = MaterialTheme.typography.headlineMedium)
                }
                IconButton(onClick = {}) { Icon(Icons.Filled.Notifications, contentDescription = "Notifications") }
            }
        }
        item { SectionHeader("Live now") }
        item {
            LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(Repo.streams, key = { it.id }) { s ->
                    StreamCard(s, Modifier.width(170.dp).height(240.dp)) { onStream(s.id) }
                }
            }
        }
        item { SectionHeader("Voice rooms") }
        items(Repo.rooms, key = { it.id }) { r -> RoomRow(r) { onRoom(r.id) } }
    }
}
