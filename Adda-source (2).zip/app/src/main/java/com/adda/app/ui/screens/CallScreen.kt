package com.adda.app.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import com.adda.app.data.*
import com.adda.app.rtc.*
import com.adda.app.service.CallService
import com.adda.app.ui.*
import com.adda.app.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.math.sin
import kotlin.random.Random

@Composable
fun CallScreen(userId: String, video: Boolean, onEnd: () -> Unit) {
    val ctx = LocalContext.current
    val user = remember(userId) { Repo.user(userId) }
    var granted by remember { mutableStateOf(hasMedia(ctx, video)) }
    val request = rememberMediaPermission(video) { granted = it }
    val rtc by Rtc.engine.state.collectAsState()
    var speaker by remember { mutableStateOf(true) }
    val (a, b) = gradientFor(user.id)

    LaunchedEffect(Unit) { if (!granted) request() }
    LaunchedEffect(granted) {
        if (granted) {
            delay(2200)
            Rtc.engine.join("call-$userId", video)
            CallService.start(ctx, "Call with ${user.name}")
        }
    }
    DisposableEffect(Unit) {
        onDispose {
            Rtc.engine.leave()
            CallService.stop(ctx)
        }
    }

    val status = when {
        !granted -> "Allow microphone access to start the call"
        !rtc.joined -> "Ringing"
        else -> "%02d:%02d".format(rtc.seconds / 60, rtc.seconds % 60)
    }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(a.copy(alpha = 0.55f), Ink, Ink)))) {
        Column(
            Modifier.align(Alignment.Center).offset(y = (-40).dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Avatar(user.name, user.id, 140.dp, ring = true)
            Spacer(Modifier.height(20.dp))
            Text(user.name, style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(4.dp))
            Text(status, color = TextLo, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 32.dp))
        }

        if (video && granted && (!rtc.joined || rtc.cameraOn)) {
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .statusBarsPadding()
                    .padding(16.dp)
                    .size(width = 110.dp, height = 150.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(Raised)
            ) {
                CameraPreview(Modifier.fillMaxSize(), front = true)
            }
        }

        Row(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(bottom = 32.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            RoundAction(
                if (rtc.micMuted) Icons.Filled.MicOff else Icons.Filled.Mic,
                { Rtc.engine.setMicMuted(!rtc.micMuted) },
                bg = if (rtc.micMuted) Color.White else Color(0x33FFFFFF),
                tint = if (rtc.micMuted) Ink else Color.White
            )
            if (video) {
                RoundAction(
                    if (rtc.cameraOn) Icons.Filled.Videocam else Icons.Filled.VideocamOff,
                    { Rtc.engine.setCameraOn(!rtc.cameraOn) },
                    bg = if (rtc.cameraOn) Color(0x33FFFFFF) else Color.White,
                    tint = if (rtc.cameraOn) Color.White else Ink
                )
            }
            RoundAction(
                Icons.Filled.VolumeUp, { speaker = !speaker },
                bg = if (speaker) Gold else Color(0x33FFFFFF),
                tint = if (speaker) Ink else Color.White
            )
            RoundAction(Icons.Filled.CallEnd, onEnd, bg = Hibiscus, size = 64.dp)
        }
    }
}
