package com.adda.app.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import com.adda.app.data.*
import com.adda.app.rtc.*
import com.adda.app.service.CallService
import com.adda.app.ui.*
import com.adda.app.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.math.sin
import kotlin.random.Random

@Composable
fun LiveListScreen(onStream: (String) -> Unit, onGoLive: () -> Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Live", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.weight(1f))
            GoldButton("Go live", onGoLive, icon = Icons.Filled.Videocam)
        }
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(Repo.streams, key = { it.id }) { s ->
                StreamCard(s, Modifier.fillMaxWidth().aspectRatio(0.72f)) { onStream(s.id) }
            }
        }
    }
}

@Composable
fun StreamViewerScreen(id: String, onBack: () -> Unit) {
    val s = remember(id) { Repo.stream(id) }
    val (a, b) = gradientFor(s.id)
    val comments = remember { mutableStateListOf<RoomLine>() }
    val hearts = remember { mutableStateListOf<Int>() }
    var nextHeart by remember { mutableIntStateOf(0) }
    var viewers by remember { mutableIntStateOf(s.viewers) }
    var following by remember { mutableStateOf(false) }
    var text by remember { mutableStateOf("") }

    LaunchedEffect(id) {
        var i = 0
        while (true) {
            delay(1800)
            comments.add(Repo.streamComments[i % Repo.streamComments.size])
            i++
            viewers += Random.nextInt(-2, 5)
            if (comments.size > 30) comments.removeAt(0)
        }
    }

    fun send() {
        if (text.isNotBlank()) {
            comments.add(RoomLine("You", text.trim()))
            text = ""
        }
    }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(a, b, Ink)))) {
        Avatar(s.host.name, s.host.id, 160.dp, Modifier.align(Alignment.Center).offset(y = (-60).dp))
        Text(
            "Demo stream preview", color = Color(0x99FFFFFF), style = MaterialTheme.typography.labelMedium,
            modifier = Modifier.align(Alignment.Center).offset(y = 50.dp)
        )

        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Row(
                    Modifier.clip(RoundedCornerShape(50)).background(Color(0x66000000)).padding(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Avatar(s.host.name, s.host.id, 36.dp)
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Text(s.host.name, color = Color.White, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        Text(s.category, color = Color(0xCCFFFFFF), style = MaterialTheme.typography.labelSmall)
                    }
                    Spacer(Modifier.width(10.dp))
                    Text(
                        if (following) "Following" else "Follow",
                        color = Ink, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium,
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(Gold)
                            .clickable { following = !following }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                }
                Spacer(Modifier.weight(1f))
                CountPill(Icons.Filled.Visibility, fmt(viewers))
                Spacer(Modifier.width(8.dp))
                RoundAction(Icons.Filled.Close, onBack, size = 40.dp)
            }

            Spacer(Modifier.weight(1f))

            Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                comments.takeLast(5).forEach { c ->
                    Row(
                        Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0x66000000))
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(c.who, color = Gold, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                        Spacer(Modifier.width(6.dp))
                        Text(c.text, color = Color.White, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }

            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                MessageField(text, { text = it }, "Add a comment", { send() }, Modifier.weight(1f))
                Spacer(Modifier.width(8.dp))
                RoundAction(Icons.Filled.Favorite, { hearts.add(nextHeart++) }, bg = Hibiscus, size = 48.dp)
                Spacer(Modifier.width(8.dp))
                RoundAction(Icons.Filled.CardGiftcard, { comments.add(RoomLine("You", "sent a rose")) }, bg = Gold, tint = Ink, size = 48.dp)
            }
        }

        Box(Modifier.align(Alignment.BottomEnd).padding(end = 28.dp, bottom = 110.dp)) {
            hearts.forEach { h ->
                key(h) { FloatingHeart(h) { hearts.remove(h) } }
            }
        }
    }
}

@Composable
private fun FloatingHeart(seed: Int, onDone: () -> Unit) {
    val p = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        p.animateTo(1f, tween(1600, easing = LinearOutSlowInEasing))
        onDone()
    }
    Icon(
        Icons.Filled.Favorite, contentDescription = null, tint = Hibiscus,
        modifier = Modifier.size(28.dp).graphicsLayer {
            translationY = -420.dp.toPx() * p.value
            translationX = sin(p.value * 6f + seed) * 30.dp.toPx()
            alpha = 1f - p.value
        }
    )
}

@Composable
fun GoLiveScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(hasMedia(ctx, true)) }
    val request = rememberMediaPermission(video = true) { granted = it }
    var title by remember { mutableStateOf("") }
    var live by remember { mutableStateOf(false) }
    var front by remember { mutableStateOf(true) }
    var muted by remember { mutableStateOf(false) }
    var viewers by remember { mutableIntStateOf(0) }
    var seconds by remember { mutableIntStateOf(0) }

    LaunchedEffect(live) {
        if (live) {
            seconds = 0
            viewers = 0
            while (true) {
                delay(1000)
                seconds++
                if (seconds % 2 == 0) viewers += Random.nextInt(1, 6)
            }
        }
    }
    DisposableEffect(Unit) {
        onDispose {
            Rtc.engine.leave()
            CallService.stop(ctx)
        }
    }

    fun end() {
        live = false
        Rtc.engine.leave()
        CallService.stop(ctx)
        onBack()
    }

    Box(Modifier.fillMaxSize().background(Ink)) {
        if (granted) CameraPreview(Modifier.fillMaxSize(), front)
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0x99000000), Color.Transparent, Color(0xCC000000)))
            )
        )
        if (!granted) {
            Column(Modifier.align(Alignment.Center).padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Filled.Videocam, contentDescription = null, tint = Gold, modifier = Modifier.size(44.dp))
                Spacer(Modifier.height(12.dp))
                Text("Camera and microphone access is needed to go live.", textAlign = TextAlign.Center)
                Spacer(Modifier.height(16.dp))
                GoldButton("Allow access", { request() })
            }
        }

        Row(
            Modifier.align(Alignment.TopStart).fillMaxWidth().statusBarsPadding().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RoundAction(Icons.Filled.Close, { end() }, size = 44.dp)
            if (live) {
                Spacer(Modifier.width(12.dp))
                LiveBadge()
                Spacer(Modifier.width(8.dp))
                CountPill(Icons.Filled.Visibility, fmt(viewers))
                Spacer(Modifier.weight(1f))
                Text("%02d:%02d".format(seconds / 60, seconds % 60), color = Color.White, style = MaterialTheme.typography.labelMedium)
            }
        }

        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().imePadding().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (!live) {
                MessageField(title, { title = it }, "Add a title for your stream", {}, Modifier.fillMaxWidth(), showSend = false)
                GoldButton(
                    "Go live",
                    {
                        live = true
                        Rtc.engine.join("live-me", true)
                        CallService.start(ctx, "You are live on Adda")
                    },
                    Modifier.fillMaxWidth(), Icons.Filled.LiveTv, enabled = granted
                )
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(20.dp), verticalAlignment = Alignment.CenterVertically) {
                    RoundAction(Icons.Filled.FlipCameraAndroid, { front = !front })
                    RoundAction(
                        if (muted) Icons.Filled.MicOff else Icons.Filled.Mic,
                        { muted = !muted; Rtc.engine.setMicMuted(muted) },
                        bg = if (muted) Color.White else Color(0x33FFFFFF),
                        tint = if (muted) Ink else Color.White
                    )
                    RoundAction(Icons.Filled.CallEnd, { end() }, bg = Hibiscus, size = 64.dp)
                }
            }
        }
    }
}
