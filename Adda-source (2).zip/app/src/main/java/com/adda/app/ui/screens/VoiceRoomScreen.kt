package com.adda.app.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import com.adda.app.data.*
import com.adda.app.rtc.*
import com.adda.app.service.CallService
import com.adda.app.ui.*
import com.adda.app.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.math.sin
import kotlin.random.Random

@Composable
fun VoiceRoomScreen(roomId: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val room = remember(roomId) { Repo.room(roomId) }
    val rtc by Rtc.engine.state.collectAsState()
    var mySeat by remember { mutableStateOf<Int?>(null) }
    var pendingSeat by remember { mutableStateOf<Int?>(null) }
    val lines = remember { mutableStateListOf<RoomLine>().apply { addAll(Repo.roomLines) } }
    var text by remember { mutableStateOf("") }
    val iAmHost = room.host.id == "me"

    val request = rememberMediaPermission(video = false) { ok ->
        val seat = pendingSeat
        if (ok && seat != null) {
            mySeat = seat
            Rtc.engine.setMicMuted(false)
            CallService.start(ctx, room.title)
        }
        pendingSeat = null
    }

    LaunchedEffect(roomId) {
        Rtc.engine.join("room-$roomId", false)
        Rtc.engine.setMicMuted(true)
        if (iAmHost) {
            pendingSeat = 0
            request()
        }
    }
    LaunchedEffect(roomId) {
        var i = 0
        while (true) {
            delay(3500)
            lines.add(RoomLine(Repo.users.random().name, Repo.chatter[i % Repo.chatter.size]))
            i++
            if (lines.size > 60) lines.removeAt(0)
        }
    }
    DisposableEffect(roomId) {
        onDispose {
            Rtc.engine.leave()
            CallService.stop(ctx)
        }
    }

    fun occupant(i: Int): User? = when {
        i == mySeat -> Repo.me
        i == 0 -> room.host
        i - 1 < room.guests.size -> room.guests[i - 1]
        else -> null
    }

    fun onSeat(i: Int) {
        when {
            mySeat == i && !(i == 0 && iAmHost) -> {
                mySeat = null
                Rtc.engine.setMicMuted(true)
                CallService.stop(ctx)
            }
            occupant(i) == null && mySeat == null -> {
                pendingSeat = i
                request()
            }
        }
    }

    fun send() {
        if (text.isNotBlank()) {
            lines.add(RoomLine("You", text.trim()))
            text = ""
        }
    }

    val listState = rememberLazyListState()
    LaunchedEffect(lines.size) { if (lines.isNotEmpty()) listState.animateScrollToItem(lines.lastIndex) }

    Column(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(gradientFor(room.id).first.copy(alpha = 0.35f), Ink, Ink)))
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
            Column(Modifier.weight(1f)) {
                Text(room.title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${fmt(room.listeners)} listening", color = TextLo, style = MaterialTheme.typography.labelMedium)
            }
            IconButton(onClick = {}) { Icon(Icons.Filled.Share, contentDescription = "Share") }
        }

        for (row in 0..1) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                for (col in 0..3) {
                    val i = row * 4 + col
                    val u = occupant(i)
                    val speaking = u != null && rtc.speaking.contains(i) && !(i == mySeat && rtc.micMuted)
                    SeatView(
                        index = i, user = u, isMe = i == mySeat, speaking = speaking,
                        muted = i == mySeat && rtc.micMuted, onClick = { onSeat(i) }
                    )
                }
            }
        }

        LazyColumn(
            Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp),
            state = listState,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(lines) { l ->
                Row {
                    Text(l.who, color = Gold, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.width(8.dp))
                    Text(l.text, color = TextHi, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                }
            }
        }

        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            MessageField(text, { text = it }, "Say something", { send() }, Modifier.weight(1f))
            if (mySeat != null) {
                Spacer(Modifier.width(8.dp))
                RoundAction(
                    icon = if (rtc.micMuted) Icons.Filled.MicOff else Icons.Filled.Mic,
                    onClick = { Rtc.engine.setMicMuted(!rtc.micMuted) },
                    bg = if (rtc.micMuted) Raised else Gold,
                    tint = if (rtc.micMuted) TextHi else Ink,
                    size = 48.dp
                )
            }
            Spacer(Modifier.width(8.dp))
            RoundAction(
                icon = Icons.Filled.CardGiftcard,
                onClick = { lines.add(RoomLine("You", "sent a rose")) },
                bg = Hibiscus, size = 48.dp
            )
        }
    }
}

@Composable
private fun SeatView(index: Int, user: User?, isMe: Boolean, speaking: Boolean, muted: Boolean, onClick: () -> Unit) {
    val ring by animateFloatAsState(if (speaking) 1f else 0f, tween(250), label = "ring")
    Column(Modifier.width(80.dp).clickable(onClick = onClick), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(70.dp), contentAlignment = Alignment.Center) {
            Box(
                Modifier
                    .size(70.dp)
                    .graphicsLayer {
                        alpha = ring
                        scaleX = 1f + 0.08f * ring
                        scaleY = 1f + 0.08f * ring
                    }
                    .border(3.dp, Mint, CircleShape)
            )
            if (user != null) {
                Avatar(user.name, user.id, 58.dp, ring = index == 0)
            } else {
                Box(
                    Modifier.size(58.dp).clip(CircleShape).background(Surface1).border(1.dp, Raised, CircleShape),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Filled.Add, contentDescription = "Take seat", tint = TextLo) }
            }
            if (user != null && muted) {
                Box(
                    Modifier.align(Alignment.BottomEnd).size(22.dp).clip(CircleShape).background(Ink),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Filled.MicOff, contentDescription = "Muted", tint = Hibiscus, modifier = Modifier.size(14.dp)) }
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(
            if (user == null) "${index + 1}" else if (isMe) "You" else user.name,
            style = MaterialTheme.typography.labelMedium,
            color = if (user == null) TextLo else TextHi,
            maxLines = 1
        )
        if (index == 0 && user != null) Text("Host", color = Gold, style = MaterialTheme.typography.labelSmall)
    }
}
