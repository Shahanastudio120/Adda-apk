package com.adda.app.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import com.adda.app.data.*
import com.adda.app.rtc.*
import com.adda.app.service.CallService
import com.adda.app.ui.*
import com.adda.app.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.math.sin
import kotlin.random.Random

@Composable
fun ChatListScreen(onOpen: (String) -> Unit) {
    val all by Repo.messages.collectAsState()
    LazyColumn(Modifier.fillMaxSize().statusBarsPadding()) {
        item {
            Text(
                "Messages", style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 8.dp)
            )
        }
        items(Repo.threads, key = { it.id }) { t ->
            val last = all[t.id]?.lastOrNull()
            Row(
                Modifier.fillMaxWidth().clickable { onOpen(t.id) }.padding(horizontal = 20.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Avatar(t.user.name, t.user.id, 54.dp, ring = t.user.vip)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(t.user.name, style = MaterialTheme.typography.titleMedium)
                    Text(
                        last?.text.orEmpty(), color = TextLo, maxLines = 1,
                        overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(last?.time.orEmpty(), color = TextLo, style = MaterialTheme.typography.labelSmall)
                    if (t.unread > 0) {
                        Spacer(Modifier.height(6.dp))
                        Box(Modifier.size(20.dp).clip(CircleShape).background(Hibiscus), contentAlignment = Alignment.Center) {
                            Text("${t.unread}", color = Color.White, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ChatScreen(userId: String, onBack: () -> Unit, onCall: (Boolean) -> Unit) {
    val user = remember(userId) { Repo.user(userId) }
    val all by Repo.messages.collectAsState()
    val msgs = all[userId].orEmpty()
    var text by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.lastIndex) }

    fun send() {
        if (text.isNotBlank()) {
            Repo.send(userId, text.trim())
            text = ""
        }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
            Avatar(user.name, user.id, 40.dp, ring = user.vip)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(user.name, style = MaterialTheme.typography.titleMedium)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(7.dp).clip(CircleShape).background(Mint))
                    Spacer(Modifier.width(5.dp))
                    Text("Online", color = TextLo, style = MaterialTheme.typography.labelMedium)
                }
            }
            IconButton(onClick = { onCall(false) }) { Icon(Icons.Filled.Call, contentDescription = "Voice call") }
            IconButton(onClick = { onCall(true) }) { Icon(Icons.Filled.Videocam, contentDescription = "Video call") }
        }
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(),
            state = listState,
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(msgs, key = { it.id }) { m -> Bubble(m) }
        }
        MessageField(text, { text = it }, "Message", { send() }, Modifier.fillMaxWidth().padding(12.dp))
    }
}

@Composable
private fun Bubble(m: ChatMessage) {
    Column(Modifier.fillMaxWidth(), horizontalAlignment = if (m.mine) Alignment.End else Alignment.Start) {
        Box(
            Modifier
                .widthIn(max = 280.dp)
                .clip(
                    RoundedCornerShape(
                        topStart = 18.dp, topEnd = 18.dp,
                        bottomEnd = if (m.mine) 4.dp else 18.dp,
                        bottomStart = if (m.mine) 18.dp else 4.dp
                    )
                )
                .background(if (m.mine) Gold else Raised)
                .padding(horizontal = 14.dp, vertical = 9.dp)
        ) {
            Text(m.text, color = if (m.mine) Ink else TextHi)
        }
        Text(
            m.time, style = MaterialTheme.typography.labelSmall, color = TextLo,
            modifier = Modifier.padding(top = 2.dp, start = 4.dp, end = 4.dp)
        )
    }
}
