package com.adda.app.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import com.adda.app.data.*
import com.adda.app.rtc.*
import com.adda.app.service.CallService
import com.adda.app.ui.*
import com.adda.app.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.math.sin
import kotlin.random.Random

@Composable
fun RoomsScreen(onRoom: (String) -> Unit) {
    val cats = listOf("For you", "Music", "Poetry", "Sports", "Business", "Chill")
    var sel by remember { mutableStateOf(cats[0]) }
    val list = Repo.rooms.filter { sel == "For you" || it.topic == sel }
    Box(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = PaddingValues(bottom = 96.dp)) {
            item {
                Text(
                    "Voice rooms", style = MaterialTheme.typography.headlineMedium,
                    modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 12.dp)
                )
            }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(cats) { c ->
                        FilterChip(
                            selected = sel == c,
                            onClick = { sel = c },
                            label = { Text(c) },
                            border = null,
                            colors = FilterChipDefaults.filterChipColors(
                                containerColor = Surface1, labelColor = TextLo,
                                selectedContainerColor = Gold, selectedLabelColor = Ink
                            )
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
            items(list, key = { it.id }) { r -> RoomRow(r) { onRoom(r.id) } }
        }
        GoldButton(
            "Start a room", { onRoom("new") },
            Modifier.align(Alignment.BottomCenter).padding(bottom = 20.dp), Icons.Filled.Mic
        )
    }
}
