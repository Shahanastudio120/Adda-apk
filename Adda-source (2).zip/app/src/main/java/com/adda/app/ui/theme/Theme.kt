package com.adda.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Ink = Color(0xFF0B0F1E)
val Surface1 = Color(0xFF141A2E)
val Raised = Color(0xFF1D2540)
val Gold = Color(0xFFFFB547)
val Hibiscus = Color(0xFFFF4D79)
val Mint = Color(0xFF3DDC97)
val TextHi = Color(0xFFF2F4FA)
val TextLo = Color(0xFF8E97B5)

private val AddaColors = darkColorScheme(
    primary = Gold, onPrimary = Ink,
    secondary = Hibiscus, onSecondary = Color.White,
    background = Ink, onBackground = TextHi,
    surface = Surface1, onSurface = TextHi,
    surfaceVariant = Raised, onSurfaceVariant = TextLo,
    error = Hibiscus
)

private val AddaType = Typography(
    headlineLarge = TextStyle(fontSize = 36.sp, lineHeight = 40.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-0.8).sp),
    headlineMedium = TextStyle(fontSize = 26.sp, lineHeight = 30.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.4).sp),
    titleLarge = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.Bold),
    titleMedium = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = TextStyle(fontSize = 15.sp, lineHeight = 21.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 19.sp),
    labelMedium = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Medium),
    labelSmall = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Medium)
)

@Composable
fun AddaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AddaColors,
        typography = AddaType,
        shapes = Shapes(
            small = RoundedCornerShape(10.dp),
            medium = RoundedCornerShape(14.dp),
            large = RoundedCornerShape(22.dp)
        ),
        content = content
    )
}
