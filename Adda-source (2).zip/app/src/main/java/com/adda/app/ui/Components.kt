package com.adda.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.adda.app.data.LiveStream
import com.adda.app.data.VoiceRoom
import com.adda.app.ui.theme.*
import java.util.Locale

private val pairs = listOf(
    Gold to Hibiscus,
    Color(0xFF7C5CFF) to Color(0xFF3DB6FF),
    Mint to Color(0xFF2B7BFF),
    Hibiscus to Color(0xFF7C5CFF),
    Color(0xFFFF8A3D) to Color(0xFFFFD36B)
)

fun gradientFor(seed: String): Pair<Color, Color> = pairs[(seed.hashCode() and 0x7fffffff) % pairs.size]

fun fmt(n: Int): String = if (n >= 1000) String.format(Locale.US, "%.1fk", n / 1000f) else n.toString()

@Composable
fun Avatar(name: String, seed: String, size: Dp, modifier: Modifier = Modifier, ring: Boolean = false) {
    val (a, b) = gradientFor(seed)
    Box(
        modifier
            .size(size)
            .clip(CircleShape)
            .background(Brush.linearGradient(listOf(a, b)))
            .then(if (ring) Modifier.border(2.dp, Gold, CircleShape) else Modifier),
        contentAlignment = Alignment.Center
    ) {
        Text(
            name.take(1).uppercase(),
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = (size.value * 0.4f).sp
        )
    }
}

@Composable
fun LiveBadge(modifier: Modifier = Modifier) {
    Row(
        modifier.clip(RoundedCornerShape(50)).background(Hibiscus).padding(horizontal = 8.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(6.dp).clip(CircleShape).background(Color.White))
        Spacer(Modifier.width(5.dp))
        Text("Live", color = Color.White, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun CountPill(icon: ImageVector, text: String, modifier: Modifier = Modifier) {
    Row(
        modifier.clip(RoundedCornerShape(50)).background(Color(0x66000000)).padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
        Spacer(Modifier.width(4.dp))
        Text(text, color = Color.White, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
fun GoldButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    enabled: Boolean = true
) {
    Button(
        onClick = onClick,
        modifier = modifier.heightIn(min = 48.dp),
        enabled = enabled,
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = Gold, contentColor = Ink,
            disabledContainerColor = Raised, disabledContentColor = TextLo
        )
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(text, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun RoundAction(
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    bg: Color = Color(0x33FFFFFF),
    tint: Color = Color.White,
    size: Dp = 56.dp
) {
    Box(
        modifier.size(size).clip(CircleShape).background(bg).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = null, tint = tint)
    }
}

@Composable
fun SectionHeader(title: String) {
    Text(
        title,
        style = MaterialTheme.typography.titleLarge,
        modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 22.dp, bottom = 10.dp)
    )
}

@Composable
fun MessageField(
    value: String,
    onChange: (String) -> Unit,
    placeholder: String,
    onSend: () -> Unit,
    modifier: Modifier = Modifier,
    showSend: Boolean = true
) {
    TextField(
        value = value,
        onValueChange = onChange,
        modifier = modifier,
        singleLine = true,
        shape = RoundedCornerShape(50),
        placeholder = { Text(placeholder, color = TextLo) },
        trailingIcon = {
            if (showSend) {
                IconButton(onClick = onSend) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Gold)
                }
            }
        },
        keyboardOptions = KeyboardOptions(imeAction = if (showSend) ImeAction.Send else ImeAction.Done),
        keyboardActions = KeyboardActions(onSend = { onSend() }, onDone = { onSend() }),
        colors = TextFieldDefaults.colors(
            focusedContainerColor = Surface1,
            unfocusedContainerColor = Surface1,
            focusedIndicatorColor = Color.Transparent,
            unfocusedIndicatorColor = Color.Transparent,
            cursorColor = Gold,
            focusedTextColor = TextHi,
            unfocusedTextColor = TextHi
        )
    )
}

@Composable
fun StreamCard(s: LiveStream, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val (a, b) = gradientFor(s.id)
    Box(
        modifier
            .clip(RoundedCornerShape(22.dp))
            .background(Brush.verticalGradient(listOf(a.copy(alpha = 0.9f), b.copy(alpha = 0.7f), Ink)))
            .clickable(onClick = onClick)
    ) {
        LiveBadge(Modifier.align(Alignment.TopStart).padding(10.dp))
        CountPill(Icons.Filled.Visibility, fmt(s.viewers), Modifier.align(Alignment.TopEnd).padding(10.dp))
        Avatar(s.host.name, s.host.id, 72.dp, Modifier.align(Alignment.Center), ring = true)
        Column(Modifier.align(Alignment.BottomStart).padding(12.dp)) {
            Text(
                s.title, color = Color.White, maxLines = 2, overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.titleMedium
            )
            Text(s.host.name, color = Color(0xCCFFFFFF), style = MaterialTheme.typography.labelMedium)
        }
    }
}

@Composable
fun RoomRow(r: VoiceRoom, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(Surface1)
            .clickable(onClick = onClick)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar(r.host.name, r.host.id, 52.dp, ring = true)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(r.title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("Hosted by ${r.host.name}, ${r.topic}", color = TextLo, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(8.dp))
            Row {
                r.guests.take(4).forEachIndexed { i, g ->
                    Avatar(g.name, g.id, 22.dp, Modifier.offset(x = (-6 * i).dp))
                }
            }
        }
        Column(horizontalAlignment = Alignment.End) {
            Icon(Icons.Filled.GraphicEq, contentDescription = null, tint = Mint)
            Text(fmt(r.listeners), color = TextLo, style = MaterialTheme.typography.labelMedium)
        }
    }
}
