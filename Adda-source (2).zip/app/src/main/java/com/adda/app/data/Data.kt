package com.adda.app.data

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class User(val id: String, val name: String, val bio: String, val followers: Int, val vip: Boolean = false)
data class VoiceRoom(val id: String, val title: String, val topic: String, val host: User, val listeners: Int, val guests: List<User>)
data class LiveStream(val id: String, val title: String, val category: String, val host: User, val viewers: Int)
data class ChatThread(val id: String, val user: User, val unread: Int)
data class ChatMessage(val id: Long, val mine: Boolean, val text: String, val time: String)
data class RoomLine(val who: String, val text: String)

/**
 * Demo data layer. Everything here runs offline.
 * Swap this object for Firebase / Supabase / your own API when you add a backend.
 */
object Repo {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var nextId = 100L

    var meName by mutableStateOf("You")
    val me: User get() = User("me", meName, "New on Adda", 0, false)

    val users = listOf(
        User("u1", "Nila", "Late-night poetry and lo-fi", 12400, true),
        User("u2", "Rafi", "Cricket talk, no filter", 8300),
        User("u3", "Tania", "Singer. Requests open.", 21900, true),
        User("u4", "Arman", "Startup stories from Dhaka", 5600),
        User("u5", "Mim", "Book club every Friday", 3100),
        User("u6", "Sajid", "Gaming squad leader", 9800),
        User("u7", "Priya", "Travel diaries", 7400),
        User("u8", "Imran", "Guitar covers", 4200, true)
    )

    private fun u(id: String) = users.first { it.id == id }
    fun user(id: String): User = if (id == "me") me else u(id)

    val rooms = listOf(
        VoiceRoom("r1", "Midnight poetry", "Poetry", u("u1"), 342, listOf(u("u3"), u("u5"), u("u8"))),
        VoiceRoom("r2", "Friday cricket adda", "Sports", u("u2"), 518, listOf(u("u4"), u("u6"))),
        VoiceRoom("r3", "Open mic: your song, your turn", "Music", u("u3"), 967, listOf(u("u8"), u("u1"), u("u7"), u("u5"))),
        VoiceRoom("r4", "Founders, honest hour", "Business", u("u4"), 204, listOf(u("u2"))),
        VoiceRoom("r5", "Chill and chat", "Chill", u("u7"), 131, listOf(u("u5"), u("u6")))
    )

    fun room(id: String): VoiceRoom =
        if (id == "new") VoiceRoom("new", "$meName's room", "Chill", me, 1, emptyList())
        else rooms.first { it.id == id }

    val streams = listOf(
        LiveStream("s1", "Acoustic night, requests open", "Music", u("u8"), 1830),
        LiveStream("s2", "Ranked grind to Conqueror", "Gaming", u("u6"), 2640),
        LiveStream("s3", "Cooking kacchi from scratch", "Food", u("u5"), 940),
        LiveStream("s4", "Cox's Bazar sunset walk", "Travel", u("u7"), 1215),
        LiveStream("s5", "Ask me anything about startups", "Talk", u("u4"), 488),
        LiveStream("s6", "Evening ghazal session", "Music", u("u3"), 3120)
    )

    fun stream(id: String): LiveStream = streams.first { it.id == id }

    val roomLines = listOf(
        RoomLine("Nila", "Welcome in. Take a seat if you want to speak."),
        RoomLine("Tania", "That last line gave me goosebumps."),
        RoomLine("Mim", "Joined from Chattogram")
    )
    val chatter = listOf(
        "Volume is perfect", "Take a seat, we don't bite", "Next round, please",
        "Who is up after this?", "Replay that part", "Sending a rose"
    )
    val streamComments = listOf(
        RoomLine("Rafi", "Sound is crystal clear"), RoomLine("Mim", "Hello from Sylhet"),
        RoomLine("Sajid", "That was clean"), RoomLine("Priya", "Can you play it again?"),
        RoomLine("Arman", "Following now"), RoomLine("Nila", "Love this")
    )

    val threads = listOf("u1", "u3", "u2", "u5", "u6").mapIndexed { i, id ->
        ChatThread(id, u(id), if (i == 0) 2 else 0)
    }

    private val _messages = MutableStateFlow(
        mapOf(
            "u1" to listOf(
                ChatMessage(1, false, "Your room last night was beautiful.", "9:41 PM"),
                ChatMessage(2, false, "Are you hosting again tonight?", "9:42 PM")
            ),
            "u3" to listOf(
                ChatMessage(3, true, "Can I request a song in the open mic?", "8:10 PM"),
                ChatMessage(4, false, "Always. Come take a seat.", "8:12 PM")
            ),
            "u2" to listOf(ChatMessage(5, false, "Friday cricket adda, you in?", "6:30 PM")),
            "u5" to listOf(ChatMessage(6, false, "This month's book pick is up.", "Yesterday")),
            "u6" to listOf(ChatMessage(7, true, "Squad up at 11?", "Yesterday"))
        )
    )
    val messages: StateFlow<Map<String, List<ChatMessage>>> = _messages.asStateFlow()

    private val replies = listOf("Haha yes!", "Tell me more", "Joining the room in 5", "Sounds good to me", "Send it over")

    private fun now(): String = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())

    private fun append(threadId: String, m: ChatMessage) {
        _messages.update { it + (threadId to (it[threadId].orEmpty() + m)) }
    }

    fun send(threadId: String, text: String) {
        append(threadId, ChatMessage(nextId++, true, text, now()))
        scope.launch {
            delay(1200)
            append(threadId, ChatMessage(nextId++, false, replies.random(), now()))
        }
    }
}
