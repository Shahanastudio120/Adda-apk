package com.adda.app.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner

fun hasMedia(ctx: Context, video: Boolean): Boolean {
    fun ok(p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
    return ok(Manifest.permission.RECORD_AUDIO) && (!video || ok(Manifest.permission.CAMERA))
}

/** Returns a function that asks for mic (and camera if [video]) and reports whether it was granted. */
@Composable
fun rememberMediaPermission(video: Boolean, onResult: (Boolean) -> Unit): () -> Unit {
    val callback = rememberUpdatedState(onResult)
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        val audio = r[Manifest.permission.RECORD_AUDIO] == true
        val cam = !video || r[Manifest.permission.CAMERA] == true
        callback.value(audio && cam)
    }
    return remember(video) {
        {
            val needed = buildList {
                add(Manifest.permission.RECORD_AUDIO)
                if (video) add(Manifest.permission.CAMERA)
                if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
            }
            launcher.launch(needed.toTypedArray())
        }
    }
}

/** Live camera preview. Only compose this after the camera permission is granted. */
@Composable
fun CameraPreview(modifier: Modifier = Modifier, front: Boolean = true) {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val previewView = remember { PreviewView(ctx).apply { scaleType = PreviewView.ScaleType.FILL_CENTER } }

    DisposableEffect(front, owner) {
        val future = ProcessCameraProvider.getInstance(ctx)
        future.addListener({
            try {
                val provider = future.get()
                val preview = Preview.Builder().build()
                preview.setSurfaceProvider(previewView.surfaceProvider)
                provider.unbindAll()
                provider.bindToLifecycle(
                    owner,
                    if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA,
                    preview
                )
            } catch (e: Exception) {
                // No camera available on this device
            }
        }, ContextCompat.getMainExecutor(ctx))
        onDispose {
            runCatching { if (future.isDone) future.get().unbindAll() }
        }
    }
    AndroidView(factory = { previewView }, modifier = modifier)
}
