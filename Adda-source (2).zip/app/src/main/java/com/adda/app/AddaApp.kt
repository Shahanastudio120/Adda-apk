package com.adda.app

import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.adda.app.ui.screens.*
import com.adda.app.ui.theme.*

private data class Tab(val route: String, val label: String, val icon: ImageVector)

@Composable
fun AddaApp() {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val tabs = remember {
        listOf(
            Tab("home", "Home", Icons.Filled.Home),
            Tab("rooms", "Rooms", Icons.Filled.Mic),
            Tab("live", "Live", Icons.Filled.LiveTv),
            Tab("chats", "Chats", Icons.Filled.Chat),
            Tab("me", "Me", Icons.Filled.Person)
        )
    }
    val showBar = tabs.any { it.route == route }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            if (showBar) {
                NavigationBar(containerColor = Surface1) {
                    tabs.forEach { t ->
                        NavigationBarItem(
                            selected = route == t.route,
                            onClick = {
                                nav.navigate(t.route) {
                                    popUpTo("home") { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(t.icon, contentDescription = t.label) },
                            label = { Text(t.label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Ink,
                                selectedTextColor = Gold,
                                indicatorColor = Gold,
                                unselectedIconColor = TextLo,
                                unselectedTextColor = TextLo
                            )
                        )
                    }
                }
            }
        }
    ) { pad ->
        NavHost(navController = nav, startDestination = "login", modifier = Modifier.padding(pad)) {
            composable("login") {
                LoginScreen {
                    nav.navigate("home") { popUpTo("login") { inclusive = true } }
                }
            }
            composable("home") {
                HomeScreen(
                    onRoom = { nav.navigate("room/$it") },
                    onStream = { nav.navigate("stream/$it") }
                )
            }
            composable("rooms") { RoomsScreen(onRoom = { nav.navigate("room/$it") }) }
            composable("live") {
                LiveListScreen(
                    onStream = { nav.navigate("stream/$it") },
                    onGoLive = { nav.navigate("golive") }
                )
            }
            composable("chats") { ChatListScreen(onOpen = { nav.navigate("chat/$it") }) }
            composable("me") { ProfileScreen() }

            composable("room/{id}") { e ->
                VoiceRoomScreen(e.arguments?.getString("id").orEmpty(), onBack = { nav.popBackStack() })
            }
            composable("stream/{id}") { e ->
                StreamViewerScreen(e.arguments?.getString("id").orEmpty(), onBack = { nav.popBackStack() })
            }
            composable("golive") { GoLiveScreen(onBack = { nav.popBackStack() }) }
            composable("chat/{id}") { e ->
                val id = e.arguments?.getString("id").orEmpty()
                ChatScreen(id, onBack = { nav.popBackStack() }, onCall = { video -> nav.navigate("call/$id/$video") })
            }
            composable("call/{id}/{video}") { e ->
                CallScreen(
                    userId = e.arguments?.getString("id").orEmpty(),
                    video = e.arguments?.getString("video") == "true",
                    onEnd = { nav.popBackStack() }
                )
            }
        }
    }
}
