package com.adda.app.rtc

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.random.Random

data class RtcState(
    val joined: Boolean = false,
    val micMuted: Boolean = false,
    val cameraOn: Boolean = false,
    val speaking: Set<Int> = emptySet(),
    val seconds: Int = 0
)

/**
 * The only thing the UI knows about real-time media.
 * Replace DemoRtcEngine with an Agora / ZEGOCLOUD / LiveKit implementation to get real audio and video.
 */
interface RtcEngine {
    val state: StateFlow<RtcState>
    fun join(channel: String, video: Boolean)
    fun leave()
    fun setMicMuted(muted: Boolean)
    fun setCameraOn(on: Boolean)
}

class DemoRtcEngine : RtcEngine {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: Job? = null
    private val _state = MutableStateFlow(RtcState())
    override val state: StateFlow<RtcState> = _state.asStateFlow()

    override fun join(channel: String, video: Boolean) {
        job?.cancel()
        _state.update { it.copy(joined = true, cameraOn = video, seconds = 0, speaking = emptySet()) }
        job = scope.launch {
            while (true) {
                delay(1000)
                _state.update { s ->
                    s.copy(
                        seconds = s.seconds + 1,
                        speaking = if (Random.nextInt(4) == 0) emptySet() else setOf(Random.nextInt(8), Random.nextInt(8))
                    )
                }
            }
        }
    }

    override fun leave() {
        job?.cancel()
        job = null
        _state.value = RtcState()
    }

    override fun setMicMuted(muted: Boolean) = _state.update { it.copy(micMuted = muted) }
    override fun setCameraOn(on: Boolean) = _state.update { it.copy(cameraOn = on) }
}

object Rtc {
    val engine: RtcEngine = DemoRtcEngine()
}
