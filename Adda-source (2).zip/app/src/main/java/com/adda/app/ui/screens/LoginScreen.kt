package com.adda.app.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import com.adda.app.data.*
import com.adda.app.rtc.*
import com.adda.app.service.CallService
import com.adda.app.ui.*
import com.adda.app.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.math.sin
import kotlin.random.Random

@Composable
fun LoginScreen(onContinue: () -> Unit) {
    var name by remember { mutableStateOf("") }
    fun enter() {
        Repo.meName = name.trim().ifEmpty { "You" }
        onContinue()
    }
    Box(
        Modifier
            .fillMaxSize()
            .background(Ink)
            .drawBehind {
                drawRect(
                    Brush.radialGradient(
                        colors = listOf(Gold.copy(alpha = 0.28f), Color.Transparent),
                        center = Offset(size.width * 0.8f, size.height * 0.12f),
                        radius = size.width * 0.9f
                    )
                )
                drawRect(
                    Brush.radialGradient(
                        colors = listOf(Hibiscus.copy(alpha = 0.22f), Color.Transparent),
                        center = Offset(size.width * 0.1f, size.height * 0.55f),
                        radius = size.width
                    )
                )
            }
    ) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding().padding(28.dp)
        ) {
            Spacer(Modifier.weight(1f))
            Canvas(Modifier.size(width = 128.dp, height = 80.dp)) {
                val r = size.height / 2
                drawCircle(Gold, radius = r, center = Offset(r, r))
                drawCircle(Hibiscus.copy(alpha = 0.85f), radius = r, center = Offset(size.width - r, r))
            }
            Spacer(Modifier.height(28.dp))
            Text("Talk live.\nHang out.\nBe heard.", style = MaterialTheme.typography.headlineLarge)
            Spacer(Modifier.height(12.dp))
            Text(
                "Voice rooms, live streams and private calls with people who get you.",
                color = TextLo, style = MaterialTheme.typography.bodyLarge
            )
            Spacer(Modifier.weight(1f))
            MessageField(
                value = name, onChange = { name = it }, placeholder = "Your name",
                onSend = { enter() }, modifier = Modifier.fillMaxWidth(), showSend = false
            )
            Spacer(Modifier.height(14.dp))
            GoldButton("Enter Adda", { enter() }, Modifier.fillMaxWidth())
        }
    }
}
