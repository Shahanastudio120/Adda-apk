# Compose + CameraX defaults are covered by AGP's proguard-android-optimize.txt
